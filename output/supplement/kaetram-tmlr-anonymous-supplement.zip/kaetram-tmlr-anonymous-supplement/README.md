# Anonymous TMLR review supplement

This package contains the review manuscript, the complete sealed V2 public
artifact, concise result projections, and a standalone primary-outcome verifier.

Run from this directory:

```bash
python3 scripts/opd/verify_trigger_incidence_review_bundle.py \
  --artifact-dir artifact \
  --expected-index-sha256 04a26f53ce24fa9578c0e49d55b946321347f9de2a1dd81e0739822d57978562
```

The command verifies every artifact byte against the expected digest recorded
in the review manuscript, rejects duplicate or non-finite JSON, checks the
complete registered request schedule, reclassifies the primary
parser-recoverable outcome from raw response messages, and recomputes all
registered contrasts, the
directional verdict, and seed heterogeneity.

Double-blind boundary: this standalone package intentionally excludes private
source history and the full identity-bearing model lock. The public artifact
contains their hashes and sanitized projections. Full Git-blob and model-lock
authentication is available from the repository verifier after deanonymization;
the anonymous verifier reports that tier as deferred rather than silently
pretending it has authenticated hidden history.
